**17/05/2014** : 
WPP is now available in Russian. Thanks to VSharmanov.

**09/09/2013** : 
Carlos Paniago and Paskysky have joined the team. They will help into the translation (Portugues and Spanish).

**09/06/2013** : _Release V1.2.1306.09_
**English** : WPP is now available in German language.
**Français** : WPP est maintenant disponible en Allemand.

**15/05/2013** : _Release V1.2.1305.15_
**English** : Adding a new feature that allow you to launch remotely the installation of updates. The tool 'Delete Empty Product' is now part of WPP.
**Français** : Ajout d'une nouvelle fonctionnalité qui permet de lancer à distance l'installation des mises à jour. L'outil 'Delete Empty Product' est intégré dans WPP.

**03/05/2013** : _Release V1.1.1305.03_
**English** : Many bug fix and enhancements. Adding a tool to delete Products that haven't any udpates but still present in the Database.
**Français** : Nombreuse corrections et nouvelles fonctionnalités. Ajouté un outil pour supprimer les "Produits" qui n'ont plus de mises à jour mais qui restent présent dans la base de données. 

**22/02/2013** : _Release V1.1.1302.22_
**English** : Now compatible with WSUS 4.0 (on Server 2012).Added a new feature to find computers that are present in Active Directory and not in WSUS. Show WSUS Client ID for these computers. Ability to reset the WSUS Client ID remotely.
**Français** : Compatible avec Wsus 4.0 (sur Serveur 2012). Ajouté une nouvelle fonctionnalité pour trouver les ordinateurs qui sont présent dans Active Directory et pas dans Wsus. Montre les Wsus Client ID pour ces ordinateurs. Permet de réinitialiser ce Wsus Client ID à distance. 

**03/11/2012** : _Release V1.1.12.11.03_
**English** : Adding two more rules. Adding tools (MSI Property reader and ScriptLauncher). Adding a report tab to view update status on all computer group (even on Downstream servers) in one view.
**Français** : Ajouté deux nouvelles règles. Ajouté deux outils (MSI Property reader et ScriptLauncher). Ajouté un onglet 'Rapport' pour visualiser le status des mises à jour dans tous les groupes d'ordinateur (même les groupes des serveurs downstream) en une seul vue.

**01/10/2012** : _Release V1.1_
**English** : Publishing first stable release.
**Français** : Publication de la première version stable.

**18/09/2012** : _Beta Release_
**English** : Ability to revise updates, and to approve it.
**Français** : Possibilité de réviser les mises à jour, et de les approuvées.

**11/08/2012** : _Beta Release_
**English** : It still missing some fonctionnality. The server name can be provide in the 'Option' page. Ability to publish MSI, MSP and EXE.
**Français** : Il manque encore quelques fonctionnalités. Le nom du serveur peut être indiqué dans la page des options. Publication de MSI, MSP et EXE. 

**03/06/2012** : _Alpha stage_
**English** : Not all features are implemented. Server name is hard coding and there'is no option for generating the signing certificate. Only MSI files are supported. No reports available.
**Français** : Toutes les fonctionnalitées ne sont pas implémentées. Le nom du serveur est codé en dur dans l'application et il n'y a pas possibilité de générer le certificat de signature. Seul les fichiers MSI sont pris en charge. Aucun rapport n'est disponible.