**+Main Form : +**

![](Screenshots_image1.png)

**+An update detail : +**

![](Screenshots_Update Detail.png)

**+Creating rules : +**

![](Screenshots_MsiProductInstalled.PNG)
![](Screenshots_Create rules.png)

**+Approving updates : +**

![](Screenshots_Approvals.png)

**+Computers that are in AD but not in Wsus+**

![](Screenshots_WsusClientID.png)