**+Wsus Package Publisher - Documentation :+**

+Prerequisites+

- You **must** have Wsus Infrastructure installed and running.
- You **must** have .Net Framework 4.0 installed.
- You can install _Wsus Package Publisher_ on the Wsus Server or on a workstation (In this case, Wsus Administration Console **must** be installed on this workstation).
- If _Wsus Package Publisher_ is installed on a workstation, you **must** add the user to the "Wsus Administrators" group on to the Wsus server.
- You have to be Administrator of the computer where WPP run.
- With Windows 8, you must install RSAT (Remote Server Administration Tools) before.
- To deploy third party applications, each package will be digitaly signed by _Wsus Package Publisher_. The certificate used can be provide by you, or else can be generate by _Wsus Package Publisher_ (self signed certificate). This certificate **must** be installed on clients computers.

+ Installation Guide 10/10/13+ : [Installation Guide.pdf](Documentation_Installation Guide.pdf)
+ Creating a Code Signing Certificate+ : [Creating a Code Signing Certificate.pdf](Documentation_Creating a Code Signing Certificate.pdf)
+ Opening Firewall Ports for Remote Administration+ : [Firewall Rules for Remote Administration.pdf](Documentation_Firewall Rules for Remote Administration.pdf)
+ TightVNC Deployment with Custom Settings+ : [TightVNC Deployment with Custom Settings.pdf](Documentation_TightVNC Deployment with Custom Settings.pdf)
+ Adobe Reader XI Deployment with Custom Settings (updated)+ : [Adobe Reader XI Deployment with Custom Settings.pdf](Documentation_Adobe Reader XI Deployment with Custom Settings.pdf)
+ Uninstalling Java Auto Updater With Wsus+ : [Uninstalling Java Auto Updater with Wsus.pdf](Documentation_Uninstalling Java Auto Updater with Wsus.pdf)
+ Installing Symantec Endpoint Protection 12.1 RU2+ : [Installing Symantec Endpoint Protection 12.1RU2.pdf](Documentation_Installing Symantec Endpoint Protection 12.1RU2.pdf)
+ Installing Adobe Flash Player 11.7.700.169.pdf+ : [Installing Adobe Flash Player 11.7.700.169.pdf](Documentation_Installing Adobe Flash Player 11.7.700.169.pdf)
+ Updating Adobe Reader XI.pdf+ : [Updating Adobe Reader XI.pdf](Documentation_Updating Adobe Reader XI.pdf)
+ Creating a Custom Update 02/11/13+ : [Custom Updates.pdf](Documentation_Custom Updates.pdf)
+ Installing Java 7u21 without Java Auto Updater+ : [Installing Java 7u21 Without Java Auto Updater.pdf](Documentation_Installing Java 7u21 Without Java Auto Updater.pdf)
+ Uninstalling All Java release except the latest one+ : [Uninstalling All Java release except the latest one.pdf](Documentation_Uninstalling All Java release except the latest one.pdf)
+ Remote MSI Manager+ : [Remote MSI Manager.pdf](Documentation_Remote MSI Manager.pdf)

+Documents from Microsoft MSDN+ :

[Detection Methods.xps](Documentation_Detection Methods.xps)
[Building Detection Logic.xps](Documentation_Building Detection Logic.xps)
[Detection Logic Scenarios.xps](Documentation_Detection Logic Scenarios.xps)
[Version Detection Logic.xps](Documentation_Version Detection Logic.xps)
[General Recommendations.xps](Documentation_General Recommendations.xps)
